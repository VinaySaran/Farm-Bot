# FarmBot
An NLP based chatbot system related to Farming

Here I had given An WbPage for local where it consists of SignUp page , Login Page and then Bot Page.
